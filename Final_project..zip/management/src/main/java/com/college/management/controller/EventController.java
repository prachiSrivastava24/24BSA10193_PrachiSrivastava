package com.college.management.controller;

import com.college.management.model.Event;
import com.college.management.repository.EventRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/events")
public class EventController {

    @Autowired
    private EventRepository repo;

    // ✅ 1. CREATE
    @PostMapping
    public Event createEvent(@RequestBody Event event) {
        return repo.save(event);
    }

    // ✅ 2. READ ALL
    @GetMapping
    public List<Event> getAllEvents() {
        return repo.findAll();
    }

    // ✅ 3. READ BY ID
    @GetMapping("/{id}")
    public Event getEventById(@PathVariable String id) {
        return repo.findById(id).orElse(null);
    }

    // ✅ 4. UPDATE
    @PutMapping("/{id}")
    public Event updateEvent(@PathVariable String id, @RequestBody Event event) {
        event.setId(id);
        return repo.save(event);
    }

    // ✅ 5. DELETE
    @DeleteMapping("/{id}")
    public String deleteEvent(@PathVariable String id) {
        repo.deleteById(id);
        return "Deleted Successfully";
    }
}