package com.college.management.controller;

import com.college.management.model.Venue;
import com.college.management.repository.VenueRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/venues")
public class VenueController {

    @Autowired
    private VenueRepository repo;

    @PostMapping
    public Venue create(@RequestBody Venue v) {
        return repo.save(v);
    }

    @GetMapping
    public List<Venue> getAll() {
        return repo.findAll();
    }

    @DeleteMapping("/{id}")
    public void delete(@PathVariable String id) {
        repo.deleteById(id);
    }
}