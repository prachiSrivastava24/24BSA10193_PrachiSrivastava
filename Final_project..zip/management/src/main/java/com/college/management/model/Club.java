package com.college.management.model;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection = "clubs")
public class Club {

    @Id
    private String id;

    private String name;
    private String facultyIncharge;

    public Club() {}

    public Club(String name, String facultyIncharge) {
        this.name = name;
        this.facultyIncharge = facultyIncharge;
    }

    public String getId() { return id; }

    public String getName() { return name; }
    public void setName(String name) { this.name = name; }

    public String getFacultyIncharge() { return facultyIncharge; }
    public void setFacultyIncharge(String facultyIncharge) { this.facultyIncharge = facultyIncharge; }
}