package com.college.management.controller;

import com.college.management.model.Member;
import com.college.management.repository.MemberRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/members")
public class MemberController {

    @Autowired
    private MemberRepository repo;

    @PostMapping
    public Member create(@RequestBody Member m) {
        return repo.save(m);
    }

    @GetMapping
    public List<Member> getAll() {
        return repo.findAll();
    }

    @DeleteMapping("/{id}")
    public void delete(@PathVariable String id) {
        repo.deleteById(id);
    }
}