package com.college.management.model;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection = "venues")
public class Venue {

    @Id
    private String id;

    private String name;
    private String location;

    public Venue() {}

    public Venue(String name, String location) {
        this.name = name;
        this.location = location;
    }

    public String getId() { return id; }

    public String getName() { return name; }
    public void setName(String name) { this.name = name; }

    public String getLocation() { return location; }
    public void setLocation(String location) { this.location = location; }
}