package com.college.management.controller;

import com.college.management.model.Club;
import com.college.management.repository.ClubRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/clubs")
public class ClubController {

    @Autowired
    private ClubRepository repo;

    @PostMapping
    public Club create(@RequestBody Club c) {
        return repo.save(c);
    }

    @GetMapping
    public List<Club> getAll() {
        return repo.findAll();
    }

    @DeleteMapping("/{id}")
    public void delete(@PathVariable String id) {
        repo.deleteById(id);
    }
}