package com.college.management.controller;

import com.college.management.model.Announcement;
import com.college.management.repository.AnnouncementRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/announcements")
public class AnnouncementController {

    @Autowired
    private AnnouncementRepository repo;

    @PostMapping
    public Announcement create(@RequestBody Announcement a) {
        return repo.save(a);
    }

    @GetMapping
    public List<Announcement> getAll() {
        return repo.findAll();
    }

    @DeleteMapping("/{id}")
    public void delete(@PathVariable String id) {
        repo.deleteById(id);
    }
}