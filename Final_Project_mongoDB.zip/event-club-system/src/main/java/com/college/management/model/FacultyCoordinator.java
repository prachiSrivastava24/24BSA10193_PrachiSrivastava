package com.college.management.model;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;


@Document(collection = "faculty_coordinators")
public class FacultyCoordinator {
    
    
    @Id
    private String id;
    private String name;
    private String department;
    private String email;

    public FacultyCoordinator() {}

    public FacultyCoordinator(String name, String department, String email) {
        this.name = name;
        this.department = department;
        this.email = email;
    }

    
    public String getId() { return id; }
    public void setId(String id) { this.id = id; }
    public String getName() { return name; }
    public void setName(String name) { this.name = name; }
    public String getDepartment() { return department; }
    public void setDepartment(String department) { this.department = department; }
    public String getEmail() { return email; }
    public void setEmail(String email) { this.email = email; }
}