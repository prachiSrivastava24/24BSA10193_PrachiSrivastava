package com.college.management.service;

import com.college.management.model.Student;
import com.college.management.repository.StudentRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class StudentService {

    @Autowired
    private StudentRepository studentRepository;

    public Student addStudent(Student student) {
        return studentRepository.save(student);
    }

    public List<Student> getAllStudents() {
        return studentRepository.findAll();
    }

    public Optional<Student> getStudentById(String id) {
        return studentRepository.findById(id);
    }

    public Student updateStudent(String id, Student updatedStudentDetails) {
        Optional<Student> existingStudent = studentRepository.findById(id);
        
        if (existingStudent.isPresent()) {
            Student student = existingStudent.get();
            student.setName(updatedStudentDetails.getName());
            student.setEmail(updatedStudentDetails.getEmail());
            student.setEnrollmentNumber(updatedStudentDetails.getEnrollmentNumber());
            return studentRepository.save(student); 
        } else {
            throw new RuntimeException("Student not found with id: " + id);
        }
    }

    public void deleteStudent(String id) {
        studentRepository.deleteById(id);
    }
}