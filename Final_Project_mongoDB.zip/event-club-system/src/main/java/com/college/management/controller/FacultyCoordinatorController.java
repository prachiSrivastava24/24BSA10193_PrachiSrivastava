package com.college.management.controller;

import com.college.management.model.FacultyCoordinator;
import com.college.management.service.FacultyCoordinatorService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/api/coordinators")
public class FacultyCoordinatorController {

    @Autowired
    private FacultyCoordinatorService coordinatorService;

    @PostMapping
    public FacultyCoordinator createCoordinator(@RequestBody FacultyCoordinator coordinator) {
        return coordinatorService.addCoordinator(coordinator);
    }

    @GetMapping
    public List<FacultyCoordinator> getAllCoordinators() {
        return coordinatorService.getAllCoordinators();
    }

    @GetMapping("/{id}")
    public Optional<FacultyCoordinator> getCoordinatorById(@PathVariable String id) {
        return coordinatorService.getCoordinatorById(id);
    }

    @PutMapping("/{id}")
    public FacultyCoordinator updateCoordinator(@PathVariable String id, @RequestBody FacultyCoordinator coordinatorDetails) {
        return coordinatorService.updateCoordinator(id, coordinatorDetails);
    }

    @DeleteMapping("/{id}")
    public String deleteCoordinator(@PathVariable String id) {
        coordinatorService.deleteCoordinator(id);
        return "Coordinator deleted successfully!";
    }
}