package com.college.management.controller;

import com.college.management.model.Club;
import com.college.management.service.ClubService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/api/clubs")
public class ClubController {

    @Autowired
    private ClubService clubService;

    @PostMapping
    public Club createClub(@RequestBody Club club) {
        return clubService.addClub(club);
    }

    @GetMapping
    public List<Club> getAllClubs() {
        return clubService.getAllClubs();
    }

    @GetMapping("/{id}")
    public Optional<Club> getClubById(@PathVariable String id) {
        return clubService.getClubById(id);
    }

    @PutMapping("/{id}")
    public Club updateClub(@PathVariable String id, @RequestBody Club clubDetails) {
        return clubService.updateClub(id, clubDetails);
    }

    @DeleteMapping("/{id}")
    public String deleteClub(@PathVariable String id) {
        clubService.deleteClub(id);
        return "Club deleted successfully!";
    }
}