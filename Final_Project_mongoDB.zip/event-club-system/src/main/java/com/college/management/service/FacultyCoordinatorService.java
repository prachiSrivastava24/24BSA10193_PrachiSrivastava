package com.college.management.service;

import com.college.management.model.FacultyCoordinator;
import com.college.management.repository.FacultyCoordinatorRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class FacultyCoordinatorService {

    @Autowired
    private FacultyCoordinatorRepository coordinatorRepository;

    public FacultyCoordinator addCoordinator(FacultyCoordinator coordinator) {
        return coordinatorRepository.save(coordinator);
    }

    public List<FacultyCoordinator> getAllCoordinators() {
        return coordinatorRepository.findAll();
    }

    public Optional<FacultyCoordinator> getCoordinatorById(String id) {
        return coordinatorRepository.findById(id);
    }

    public FacultyCoordinator updateCoordinator(String id, FacultyCoordinator updatedDetails) {
        Optional<FacultyCoordinator> existingCoordinator = coordinatorRepository.findById(id);
        
        if (existingCoordinator.isPresent()) {
            FacultyCoordinator coordinator = existingCoordinator.get();
            coordinator.setName(updatedDetails.getName());
            coordinator.setDepartment(updatedDetails.getDepartment());
            coordinator.setEmail(updatedDetails.getEmail());
            return coordinatorRepository.save(coordinator); 
        } else {
            throw new RuntimeException("Coordinator not found with id: " + id);
        }
    }

    public void deleteCoordinator(String id) {
        coordinatorRepository.deleteById(id);
    }
}