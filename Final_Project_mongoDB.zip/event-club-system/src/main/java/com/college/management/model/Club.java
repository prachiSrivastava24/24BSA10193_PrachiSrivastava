package com.college.management.model;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.DBRef;
import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection = "clubs")
public class Club {
    
    @Id
    private String id;
    private String clubName;
    private String description;

    
    @DBRef
    private FacultyCoordinator coordinator;

    public Club() {}

    public Club(String clubName, String description, FacultyCoordinator coordinator) {
        this.clubName = clubName;
        this.description = description;
        this.coordinator = coordinator;
    }

    public String getId() { return id; }
    public void setId(String id) { this.id = id; }
    public String getClubName() { return clubName; }
    public void setClubName(String clubName) { this.clubName = clubName; }
    public String getDescription() { return description; }
    public void setDescription(String description) { this.description = description; }
    public FacultyCoordinator getCoordinator() { return coordinator; }
    public void setCoordinator(FacultyCoordinator coordinator) { this.coordinator = coordinator; }
}