package com.college.management.repository;

import com.college.management.model.FacultyCoordinator;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface FacultyCoordinatorRepository extends MongoRepository<FacultyCoordinator, String> {
}