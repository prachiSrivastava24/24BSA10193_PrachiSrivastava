package com.college.management.service;

import com.college.management.model.Event;
import com.college.management.repository.EventRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class EventService {

    @Autowired
    private EventRepository eventRepository;

    public Event addEvent(Event event) {
        return eventRepository.save(event);
    }

    public List<Event> getAllEvents() {
        return eventRepository.findAll();
    }

    public Optional<Event> getEventById(String id) {
        return eventRepository.findById(id);
    }

    public Event updateEvent(String id, Event updatedEventDetails) {
        Optional<Event> existingEvent = eventRepository.findById(id);
        
        if (existingEvent.isPresent()) {
            Event event = existingEvent.get();
            event.setEventName(updatedEventDetails.getEventName());
            event.setEventDate(updatedEventDetails.getEventDate());
            event.setLocation(updatedEventDetails.getLocation());
            event.setClub(updatedEventDetails.getClub());
            return eventRepository.save(event); 
        } else {
            throw new RuntimeException("Event not found with id: " + id);
        }
    }

    public void deleteEvent(String id) {
        eventRepository.deleteById(id);
    }
}