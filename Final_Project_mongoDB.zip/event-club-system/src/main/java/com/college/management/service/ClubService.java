package com.college.management.service;

import com.college.management.model.Club;
import com.college.management.repository.ClubRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class ClubService {

    @Autowired
    private ClubRepository clubRepository;

    // CREATE
    public Club addClub(Club club) {
        return clubRepository.save(club);
    }

    // READ ALL
    public List<Club> getAllClubs() {
        return clubRepository.findAll();
    }

    // READ ONE
    public Optional<Club> getClubById(String id) {
        return clubRepository.findById(id);
    }

    // UPDATE
    public Club updateClub(String id, Club updatedClubDetails) {
        Optional<Club> existingClub = clubRepository.findById(id);
        
        if (existingClub.isPresent()) {
            Club club = existingClub.get();
            club.setClubName(updatedClubDetails.getClubName());
            club.setDescription(updatedClubDetails.getDescription());
            club.setCoordinator(updatedClubDetails.getCoordinator());
            return clubRepository.save(club); 
        } else {
            throw new RuntimeException("Club not found with id: " + id);
        }
    }

    // DELETE
    public void deleteClub(String id) {
        clubRepository.deleteById(id);
    }
}