package com.college.management.model;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.DBRef;
import org.springframework.data.mongodb.core.mapping.Document;
import java.time.LocalDate;

@Document(collection = "events")
public class Event {

    @Id
    private String id;
    private String eventName;
    private LocalDate eventDate;
    private String location;

    // Many-to-One relationship: Many events can belong to one club.
    @DBRef
    private Club club;

    public Event() {}

    public Event(String eventName, LocalDate eventDate, String location, Club club) {
        this.eventName = eventName;
        this.eventDate = eventDate;
        this.location = location;
        this.club = club;
    }

    public String getId() { return id; }
    public void setId(String id) { this.id = id; }
    public String getEventName() { return eventName; }
    public void setEventName(String eventName) { this.eventName = eventName; }
    public LocalDate getEventDate() { return eventDate; }
    public void setEventDate(LocalDate eventDate) { this.eventDate = eventDate; }
    public String getLocation() { return location; }
    public void setLocation(String location) { this.location = location; }
    public Club getClub() { return club; }
    public void setClub(Club club) { this.club = club; }
}