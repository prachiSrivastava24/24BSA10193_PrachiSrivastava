package com.college.management.model;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.DBRef;
import org.springframework.data.mongodb.core.mapping.Document;
import java.time.LocalDate;

@Document(collection = "registrations")
public class Registration {

    @Id
    private String id;

    
    @DBRef
    private Student student;

    @DBRef
    private Event event;

    private LocalDate registrationDate;

    public Registration() {}

    public Registration(Student student, Event event, LocalDate registrationDate) {
        this.student = student;
        this.event = event;
        this.registrationDate = registrationDate;
    }

    public String getId() { return id; }
    public void setId(String id) { this.id = id; }
    public Student getStudent() { return student; }
    public void setStudent(Student student) { this.student = student; }
    public Event getEvent() { return event; }
    public void setEvent(Event event) { this.event = event; }
    public LocalDate getRegistrationDate() { return registrationDate; }
    public void setRegistrationDate(LocalDate registrationDate) { this.registrationDate = registrationDate; }
}