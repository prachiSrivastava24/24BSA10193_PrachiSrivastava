package com.college.management.service;

import com.college.management.model.Registration;
import com.college.management.repository.RegistrationRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class RegistrationService {

    @Autowired
    private RegistrationRepository registrationRepository;

    public Registration addRegistration(Registration registration) {
        return registrationRepository.save(registration);
    }

    public List<Registration> getAllRegistrations() {
        return registrationRepository.findAll();
    }

    public Optional<Registration> getRegistrationById(String id) {
        return registrationRepository.findById(id);
    }

    public Registration updateRegistration(String id, Registration updatedDetails) {
        Optional<Registration> existingRegistration = registrationRepository.findById(id);
        
        if (existingRegistration.isPresent()) {
            Registration registration = existingRegistration.get();
            registration.setStudent(updatedDetails.getStudent());
            registration.setEvent(updatedDetails.getEvent());
            registration.setRegistrationDate(updatedDetails.getRegistrationDate());
            return registrationRepository.save(registration); 
        } else {
            throw new RuntimeException("Registration not found with id: " + id);
        }
    }

    public void deleteRegistration(String id) {
        registrationRepository.deleteById(id);
    }
}