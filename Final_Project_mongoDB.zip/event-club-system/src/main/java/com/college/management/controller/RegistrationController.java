package com.college.management.controller;

import com.college.management.model.Registration;
import com.college.management.service.RegistrationService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/api/registrations")
public class RegistrationController {

    @Autowired
    private RegistrationService registrationService;

    @PostMapping
    public Registration createRegistration(@RequestBody Registration registration) {
        return registrationService.addRegistration(registration);
    }

    @GetMapping
    public List<Registration> getAllRegistrations() {
        return registrationService.getAllRegistrations();
    }

    @GetMapping("/{id}")
    public Optional<Registration> getRegistrationById(@PathVariable String id) {
        return registrationService.getRegistrationById(id);
    }

    @PutMapping("/{id}")
    public Registration updateRegistration(@PathVariable String id, @RequestBody Registration registrationDetails) {
        return registrationService.updateRegistration(id, registrationDetails);
    }

    @DeleteMapping("/{id}")
    public String deleteRegistration(@PathVariable String id) {
        registrationService.deleteRegistration(id);
        return "Registration deleted successfully!";
    }
}